(https://www.cnnturk.com/feed/rss/dunya/news) Örneğin bir haber sistesinden dünya haberlerini çekerek kendi web sayfanıza veya masaüstü uygulamanız entegre edebilirsiniz. Uygulamanın yapılmasında istediğiniz programlama dilini kullanabilirsiniz.

(RSS içeriği; haber, ekonomi, kültür sanat, bilim teknoloji, yaşam, magazini, spor, sağlık vb. farklı konularda olabilir.)